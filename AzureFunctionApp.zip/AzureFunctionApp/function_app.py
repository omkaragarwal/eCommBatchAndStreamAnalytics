import azure.functions as func
import logging
import json
import os

app = func.FunctionApp()

@app.service_bus_queue_trigger(arg_name="azservicebus", queue_name="ddos-alerts",
                               connection="ecommercealertsns_SERVICEBUS") 
def ddosTriggerApp(azservicebus: func.ServiceBusMessage):
    logging.info('Python ServiceBus Queue trigger processed a message: %s',
                azservicebus.get_body().decode('utf-8'))
    
    logging.info('Python ServiceBus Queue trigger processed a message.')

    message_body_bytes = azservicebus.get_body()
    message_body_str = message_body_bytes.decode('utf-8')

    try:
        alert_data = json.loads(message_body_str)
        alert_time = alert_data.get('AlertTime')
        user_id = alert_data.get('user_id')
        view_count = alert_data.get('ViewCount')
        alert_description = alert_data.get('AlertDescription')

        logging.warning(f"DDoS Alert Detected!")
        logging.warning(f"  Time: {alert_time}")
        logging.warning(f"  User ID: {user_id}")
        logging.warning(f"  View Count: {view_count}")
        logging.warning(f"  Description: {alert_description}")

        # --- IMPLEMENT YOUR ALERT HANDLING LOGIC HERE ---
        # This code will run when a message is received in the 'ddos-alerts' queue.
        # You can add actions like:
        # - Blocking the user (requires integration with your user management system)
        # - Notifying administrators (e.g., sending an email or SMS using a service)
        # - Triggering auto-scaling of resources
        # - Recording the alert in a database

        # Example: Logging more details
        logging.info(f"Full alert data: {alert_data}")

    except json.JSONDecodeError:
        logging.error(f"Error decoding Service Bus message: {message_body_str}")
    except Exception as e:
        logging.error(f"An error occurred while processing the alert: {e}")

# The following block is for local testing and will not be executed in Azure.
# if __name__ == "__main__":
#     import os
#     os.environ["ecommercealertsns_SERVICEBUS"] = "<YOUR_SERVICE_BUS_NAMESPACE_CONNECTION_STRING>"
#
#     sample_message_body = b'{"AlertTime": "2025-04-07T11:30:00Z", "user_id": "test_user_123", "ViewCount": 15, "AlertDescription": "Potential DDoS/Bot Attack"}'
#     mock_message = func.ServiceBusMessage(body=sample_message_body)
#     DDoSAlertProcessor(mock_message)
